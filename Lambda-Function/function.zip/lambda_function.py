"""This code writes data from IoT core rule via Lambda into InfluxDB"""

import json
from influxdb import InfluxDBClient

def lambda_handler(event, context):
    
    # Get measurements from AWS IoT JSON
    timestamp = json.parse(event.timestamp)
    node_id = json.parse(event.node_id)
    temperature = json.parse(event.temperature)
    humidity = json.parse(event.humidity)
    pm2_5 = json.parse(event.pm2_5)
    pm10 = json.parse(event.pm10)
    so2_we = json.parse(event.so2_we)
    so2_ae = json.parse(event.so2_ae)
    no2_we = json.parse(event.no2_we)
    no2_ae = json.parse(event.no2_ae)
    ox_we = json.parse(event.ox_we)
    ox_ae = json.parse(event.ox_ae)
    co_we = json.parse(event.co_we)
    co_ae = json.parse(event.co_ae)
    no_we = json.parse(event.no_we)
    no_ae = json.parse(event.no_ae)
    
    node_name = "Node " + str(node_id)
    
    # Set InfluxDB parameters
    host = process.env.INFLUXDBHOST
    port = process.env.INFLUXDBPORT
    user = process.env.INFLUXDBUSR
    password = process.env.INFLUXDBPWD
    dbname = process.env.INFLUXDBNAME
    
    client = InfluxDBClient(host, port, user, password, dbname)
    
    datapoints = [
        {
            "measurement": "air-quality-data",
            "tags": {
                "node_id": node_id
            },
            "time": timestamp,
            "fields": {
                "temperature_value": temperature,
                "humidity_value": humidity,
                "pm2_5_value": pm2_5,
                "pm10_value": pm10,
                "so2_we_value": so2_we,
                "so2_ae_value": so2_ae,
                "no2_we_value": no2_we,
                "no2_ae_value": no2_ae,
                "ox_we_value": ox_we,
                "ox_ae_value": ox_ae,
                "co_we_value": co_we,
                "co_ae_value": co_ae,
                "no_we_value": no_we,
                "no_ae_value": no_ae
            }
        }]
        
    console.log("Executing InfluxDB insert...");
    
    result = client.write_points(datapoints)
    
    console.log("Finished executing. Result: " + result);
    
